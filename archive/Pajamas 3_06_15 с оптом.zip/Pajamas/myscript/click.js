function click(){
	var id = document.getElementById("cl_pause");
	id.style.font = "italic 18px/1.3em Arial, 'Istok Web', sans-serif";
	//$(document).ready(function() {
					
	//				$("#carousel").play( "prev");
	//			});
}