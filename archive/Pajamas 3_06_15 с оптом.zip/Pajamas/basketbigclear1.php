<?php
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Дата в прошлом

session_start();

require_once 'login.php';

echo "<link href='Basketbig.css' type='text/css' rel='stylesheet'>";


//это удаление

$priceall = 0;
$namesurname = ""; 
$city = "";
$tel = "";
$email = "";
$id = "";

	if(isset($_GET["idclear1"])){
		$idclear = $foo_mysgli->sanitizeMySQL($_GET["idclear1"]);
		$id = $idclear;
		$k = $foo_mysgli->sanitizeMySQL($_GET["kgoods1"]);
		$idarr = $_SESSION["idbasketsmall"];
		$nid = $_SESSION["nid"];
		foreach($idarr as $k=>$v){
				if($v == $id){
						array_splice($idarr, $k, 1);
						array_splice($nid, $k, 1);
				}	
		}
		$idarrnumber = count($idarr);
		if($idarrnumber == 0){
			destroy_session_and_data();
			echo "Корзина пуста ";
			//echo"<a href='http://127.0.0.1/Pajamas/Pajamas.php'> Вернуться к покупкам</a>";
			//echo "Вернуться к покупкам";
			exit();
		}
		
		require_once 'basketbigunated.php';
	
		$_SESSION["idbasketsmall"] = $idarr;
		$_SESSION["nid"] = $nid;	
	}
	
//header('location:' . $_SERVER['PHP_SELF']);
	
	function destroy_session_and_data()
	{	
		$_SESSION = array();
		if (session_id() != "" || isset($_COOKIE[session_name()]))
		setcookie(session_name(), '', time() - 2592000, '/');
		session_destroy();
	}
?>